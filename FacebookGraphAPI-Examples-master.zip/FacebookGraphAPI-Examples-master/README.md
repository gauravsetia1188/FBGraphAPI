# FacebookGraphAPI-Examples
Examples for facebook graph api for python.

This repository contains examples of Graph API for various applications!

1.Get all posts on wall of the user.

2.Create a Likes frequency table(counter) for all posts on user's timeline.

Python modules used:

1.facebook-sdk

2.requests

3.tqdm (for progress bar)

4.tabulate (for fancy table)

